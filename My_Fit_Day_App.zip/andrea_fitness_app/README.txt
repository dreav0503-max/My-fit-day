MY FIT DAY — PERSONAL FITNESS APP

What it includes:
- Daily calories and macros
- Weight and body-fat check-ins
- Steps, water, and sleep tracking
- Weekly workout schedule
- Exercise sets/reps
- Workout completion tracking
- Weight trend chart
- Editable daily goals
- Saves data on your device using browser local storage

QUICK USE
1. Open index.html in a modern browser to preview the app.
2. For the best phone experience, host the folder on any simple static web host.
3. Once hosted, open it in Chrome on Android and choose "Add to Home screen" or "Install app".

PRIVACY
All entries are stored locally in the browser on the device. There is no account, cloud database, or coach portal in this version.
